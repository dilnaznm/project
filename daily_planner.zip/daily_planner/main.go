package main

import (
	"log"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"

	"github.com/dilnaznm/daily_planner/config"
	"github.com/dilnaznm/daily_planner/routes"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Fatal("Ошибка загрузки .env файла")
	}

	config.ConnectDatabase()

	r := gin.Default()

	routes.AuthRoutes(r)
	routes.PlannerRoutes(r)
	routes.AdminRoutes(r)

	r.Run(":8080")
}
