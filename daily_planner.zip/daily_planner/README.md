# Daily Planner API

RESTful API для управления планами и пользователями, написанный на Go с использованием Gin, GORM и JWT.

## 🛠 Технологии

- Go
- Gin Web Framework
- GORM (ORM для работы с базой данных)
- JWT (аутентификация)
- SQLite / PostgreSQL / другая СУБД (по вашему выбору)

## 📦 Установка и запуск

1. **Клонировать репозиторий**:
   ```bash
   git clone https://github.com/dilnaznm/daily_planner.git
   cd daily_planner
   ```

2. **Создать `.env` файл**:
   ```env
   JWT_SECRET=ваш_секретный_ключ
   ```

3. **Установить зависимости и запустить сервер**:
   ```bash
   go mod tidy
   go run main.go
   ```

## 🔐 Аутентификация

API использует JWT. После входа (`/api/auth/login`) вы получаете токен, который должен быть добавлен в заголовок:
```
Authorization: Bearer <token>
```

## 📬 Основные эндпоинты

### Аутентификация

- `POST /api/auth/register` – Регистрация
- `POST /api/auth/login` – Вход
- `GET /me` – Получение данных текущего пользователя (JWT)

### Планировщик

- `GET /plans` – Получить все планы
- `POST /plans` – Создать план
- `PUT /plans/:id` – Обновить план
- `DELETE /plans/:id` – Удалить план

### Админка (нужен пользователь с ролью `admin`)

- `GET /admin/users` – Получить всех пользователей
- `DELETE /admin/users/:id` – Удалить пользователя
- `PUT /admin/users/:id/role` – Изменить роль пользователя
- `GET /admin/plans` – Получить все планы

## 🧪 Тестирование

Импортируйте [коллекцию Postman](daily_planner_collection.json), чтобы протестировать API.

## 📁 Структура проекта

```
daily_planner/
├── controllers/     // Обработчики маршрутов
├── middlewares/     // JWT и права доступа
├── models/          // GORM модели
├── routes/          // Определения маршрутов
├── config/          // Подключение базы данных
├── main.go          // Точка входа
```

## 📄 Лицензия

MIT License
