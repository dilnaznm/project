package models

import "time"

type Plan struct {
	ID          uint      `json:"id" gorm:"primaryKey"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Date        time.Time `json:"date"`
	UserID      uint      `json:"user_id"`
}
