package controllers

import (
	"net/http"
	"time"

	"github.com/dilnaznm/daily_planner/config"
	"github.com/dilnaznm/daily_planner/models"
	"github.com/gin-gonic/gin"
)

func CreatePlan(c *gin.Context) {
	var plan models.Plan

	userId, exists := c.Get("userId")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "не авторизован"})
		return
	}

	if err := c.ShouldBindJSON(&plan); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	plan.Date = time.Now()
	plan.UserID = userId.(uint)

	config.DB.Create(&plan)
	c.JSON(http.StatusOK, plan)
}

func GetPlans(c *gin.Context) {
	userId, _ := c.Get("userId")
	role, _ := c.Get("role")

	var plans []models.Plan

	if role == "admin" {
		config.DB.Find(&plans)
	} else {
		config.DB.Where("user_id = ?", userId).Find(&plans)
	}

	c.JSON(http.StatusOK, plans)
}

func UpdatePlan(c *gin.Context) {
	id := c.Param("id")
	var plan models.Plan

	userId, _ := c.Get("userId")
	role, _ := c.Get("role")

	if err := config.DB.First(&plan, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "План не найден"})
		return
	}

	if role != "admin" && plan.UserID != userId.(uint) {
		c.JSON(http.StatusForbidden, gin.H{"error": "доступ запрещён"})
		return
	}

	var updatedPlan models.Plan
	if err := c.ShouldBindJSON(&updatedPlan); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	plan.Title = updatedPlan.Title
	plan.Description = updatedPlan.Description
	plan.Date = time.Now()

	config.DB.Save(&plan)
	c.JSON(http.StatusOK, plan)
}

func DeletePlan(c *gin.Context) {
	id := c.Param("id")
	var plan models.Plan

	userId, _ := c.Get("userId")
	role, _ := c.Get("role")

	if err := config.DB.First(&plan, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "План не найден"})
		return
	}

	if role != "admin" && plan.UserID != userId.(uint) {
		c.JSON(http.StatusForbidden, gin.H{"error": "доступ запрещён"})
		return
	}

	config.DB.Delete(&plan)
	c.JSON(http.StatusOK, gin.H{"message": "План удалён"})
}
