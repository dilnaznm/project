package controllers

import (
	"net/http"

	"github.com/dilnaznm/daily_planner/config"
	"github.com/dilnaznm/daily_planner/models"
	"github.com/gin-gonic/gin"
)

func GetAllUsers(c *gin.Context) {
	var users []models.User
	if err := config.DB.Find(&users).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Не удалось получить пользователей"})
		return
	}
	c.JSON(http.StatusOK, users)
}

func DeleteUser(c *gin.Context) {
	id := c.Param("id")
	if err := config.DB.Delete(&models.User{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Не удалось удалить пользователя"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Пользователь удалён"})
}

func UpdateUserRole(c *gin.Context) {
	id := c.Param("id")
	var data struct {
		Role string `json:"role"`
	}
	if err := c.ShouldBindJSON(&data); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var user models.User
	if err := config.DB.First(&user, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Пользователь не найден"})
		return
	}

	user.Role = data.Role
	config.DB.Save(&user)
	c.JSON(http.StatusOK, user)
}

func GetAllPlans(c *gin.Context) {
	var plans []models.Plan
	if err := config.DB.Preload("User").Find(&plans).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Не удалось получить планы"})
		return
	}
	c.JSON(http.StatusOK, plans)
}
