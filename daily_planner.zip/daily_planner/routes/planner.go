package routes

import (
	"github.com/dilnaznm/daily_planner/controllers"
	"github.com/dilnaznm/daily_planner/middlewares"
	"github.com/gin-gonic/gin"
)

func PlannerRoutes(router *gin.Engine) {
	planner := router.Group("/plans")
	planner.Use(middlewares.JWTMiddleware())

	planner.POST("/", controllers.CreatePlan)
	planner.GET("/", controllers.GetPlans)
	planner.PUT("/:id", controllers.UpdatePlan)
	planner.DELETE("/:id", controllers.DeletePlan)
}
