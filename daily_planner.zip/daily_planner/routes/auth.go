package routes

import (
	"github.com/dilnaznm/daily_planner/controllers"
	"github.com/dilnaznm/daily_planner/middlewares"
	"github.com/gin-gonic/gin"
)

func AuthRoutes(r *gin.Engine) {
	auth := r.Group("/api/auth")
	{
		auth.POST("/register", controllers.Register)
		auth.POST("/login", controllers.Login)

		r.GET("/me", middlewares.JWTMiddleware(), controllers.Me)
	}
}
