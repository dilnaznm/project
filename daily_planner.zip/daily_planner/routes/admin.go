package routes

import (
	"github.com/dilnaznm/daily_planner/controllers"
	"github.com/dilnaznm/daily_planner/middlewares"
	"github.com/gin-gonic/gin"
)

func AdminRoutes(r *gin.Engine) {
	admin := r.Group("/admin")
	admin.Use(middlewares.JWTMiddleware(), middlewares.AdminMiddleware())
	{
		admin.GET("/users", controllers.GetAllUsers)
		admin.DELETE("/users/:id", controllers.DeleteUser)
		admin.PUT("/users/:id/role", controllers.UpdateUserRole)

		admin.GET("/plans", controllers.GetAllPlans)
	}
}
